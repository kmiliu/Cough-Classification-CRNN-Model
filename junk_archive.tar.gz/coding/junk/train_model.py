#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
train_crnn_covid.py
End-to-end CNN + LSTM model for COVID audio classification.
"""

import os
import numpy as np
import librosa
import pandas as pd
import tensorflow as tf
from tensorflow.keras import layers, models
from sklearn.metrics import classification_report, roc_auc_score
from tqdm import tqdm

# === Paths ===
AUDIO_DIR = "/Users/kemingliu/Desktop/CoronaHack-Respiratory-Sound-Dataset/output/processed_audio_augmented"
META_CSV = "/Users/kemingliu/Desktop/CoronaHack-Respiratory-Sound-Dataset/output/merged_dataset.csv"

# === Hyperparameters ===
SR = 16000               # Sampling rate
N_MFCC = 40              # MFCC feature dimension
MAX_LEN = 100            # Max frames per audio (truncate or pad)
BATCH_SIZE = 32
EPOCHS = 30

# === Step 1: Load metadata ===
meta = pd.read_csv(META_CSV)
meta = meta.dropna(subset=["covid_test_status"])
meta["covid_test_status"] = meta["covid_test_status"].astype(int)
meta = meta[meta["covid_test_status"].isin([0, 1])]

# === Step 2: Collect audio paths ===
audio_paths, labels = [], []
for _, row in meta.iterrows():
    for col in meta.columns:
        if isinstance(row[col], str) and row[col].endswith(".wav"):
            path = row[col].replace("/data", AUDIO_DIR)
            if os.path.exists(path):
                audio_paths.append(path)
                labels.append(row["covid_test_status"])

print(f"✅ Found {len(audio_paths)} valid audio samples")

# === Step 3: Feature extraction (MFCC sequence) ===
def extract_mfcc(file_path, sr=SR, n_mfcc=N_MFCC, max_len=MAX_LEN):
    try:
        y, _ = librosa.load(file_path, sr=sr)
        mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=n_mfcc)
        if mfcc.shape[1] < max_len:
            pad_width = max_len - mfcc.shape[1]
            mfcc = np.pad(mfcc, pad_width=((0, 0), (0, pad_width)), mode="constant")
        else:
            mfcc = mfcc[:, :max_len]
        return mfcc
    except Exception as e:
        print(f"⚠️ Error processing {file_path}: {e}")
        return None

X, y = [], []
for path, label in tqdm(zip(audio_paths, labels), total=len(audio_paths)):
    features = extract_mfcc(path)
    if features is not None:
        X.append(features)
        y.append(label)

X = np.array(X)[..., np.newaxis]  # shape = (samples, 40, 100, 1)
y = np.array(y)
print(f"✅ Feature matrix shape: {X.shape}, labels: {y.shape}")

# === Step 4: Train/test split (use original 'split' if available) ===
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42
)
print(f"Train: {len(X_train)}, Test: {len(X_test)}")

# === Step 5: Define CNN + LSTM model ===
model = models.Sequential([
    layers.Conv2D(32, (3,3), activation='relu', padding='same', input_shape=(N_MFCC, MAX_LEN, 1)),
    layers.BatchNormalization(),
    layers.MaxPooling2D((2,2)),
    
    layers.Conv2D(64, (3,3), activation='relu', padding='same'),
    layers.BatchNormalization(),
    layers.MaxPooling2D((2,2)),
    
    layers.Reshape((int(N_MFCC/4)*int(MAX_LEN/4), 64)),
    layers.LSTM(64, return_sequences=False),
    layers.Dense(64, activation='relu'),
    layers.Dropout(0.3),
    layers.Dense(1, activation='sigmoid')
])

model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy', tf.keras.metrics.AUC()])
model.summary()

# === Step 6: Train ===
history = model.fit(
    X_train, y_train,
    validation_split=0.2,
    epochs=EPOCHS,
    batch_size=BATCH_SIZE,
    verbose=1
)

# === Step 7: Evaluate ===
y_pred = (model.predict(X_test) > 0.5).astype(int)
print("\n📊 Classification Report:")
print(classification_report(y_test, y_pred, digits=4))

auc = roc_auc_score(y_test, y_pred)
print(f"🌟 AUC (ROC): {auc:.4f}")

# === Step 8: Save model ===
os.makedirs("output/models", exist_ok=True)
model.save("output/models/covid_crnn_model.h5")
print("💾 Model saved to output/models/covid_crnn_model.h5")

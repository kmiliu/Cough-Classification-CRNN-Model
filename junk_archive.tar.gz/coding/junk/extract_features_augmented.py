import os
import librosa
import numpy as np
import pandas as pd
from tqdm import tqdm

AUGMENTED_DIR = "/Users/kemingliu/Desktop/CoronaHack-Respiratory-Sound-Dataset/output/processed_audio_augmented"
OUTPUT_CSV = "/Users/kemingliu/Desktop/CoronaHack-Respiratory-Sound-Dataset/output/features_augmented.csv"

def extract_features(file_path):
    try:
        y, sr = librosa.load(file_path, sr=22050)
        if len(y) < sr * 0.5:
            return None  # skip too short audio
        features = {}
        mfccs = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13)
        for i in range(13):
            features[f"mfcc_{i+1}"] = np.mean(mfccs[i])

        chroma = librosa.feature.chroma_stft(y=y, sr=sr)
        for i in range(12):
            features[f"chroma_{i+1}"] = np.mean(chroma[i])

        features["spec_centroid"] = np.mean(librosa.feature.spectral_centroid(y=y, sr=sr))
        features["spec_bw"] = np.mean(librosa.feature.spectral_bandwidth(y=y, sr=sr))
        features["rolloff"] = np.mean(librosa.feature.spectral_rolloff(y=y, sr=sr))
        features["zcr"] = np.mean(librosa.feature.zero_crossing_rate(y))
        return features
    except Exception:
        return None

# Collect all wav files
all_files = []
for root, dirs, files in os.walk(AUGMENTED_DIR):
    for f in files:
        if f.endswith(".wav"):
            all_files.append(os.path.join(root, f))

print(f"✅ Found {len(all_files)} augmented audio files")

# Extract features
records = []
for file in tqdm(all_files, desc="Extracting augmented features"):
    features = extract_features(file)
    if features:
        features["filepath"] = file
        features["covid_test_status"] = 1  # since we only augmented positives
        records.append(features)

# Save
df = pd.DataFrame(records)
df.to_csv(OUTPUT_CSV, index=False)
print(f"💾 Saved augmented feature file → {OUTPUT_CSV}")
print(f"✅ Total valid augmented samples: {len(df)}")

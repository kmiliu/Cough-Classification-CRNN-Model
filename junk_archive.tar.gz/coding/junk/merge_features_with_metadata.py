import pandas as pd

# === Paths ===
FEATURES_CSV = "/Users/kemingliu/Desktop/CoronaHack-Respiratory-Sound-Dataset/output/features2.csv"
META_CSV = "/Users/kemingliu/Desktop/CoronaHack-Respiratory-Sound-Dataset/Corona-Hack-Respiratory-Sound-Metadata.csv"
OUTPUT_CSV = "/Users/kemingliu/Desktop/CoronaHack-Respiratory-Sound-Dataset/output/merged_dataset.csv"

# === Load data ===
features_df = pd.read_csv(FEATURES_CSV)
meta_df = pd.read_csv(META_CSV, encoding="latin1")

print(f"✅ Loaded {len(features_df)} feature rows")
print(f"✅ Loaded {len(meta_df)} metadata rows")

# --- Normalize all column names ---
features_df.columns = [c.lower().strip() for c in features_df.columns]
meta_df.columns = [c.lower().strip() for c in meta_df.columns]

# --- Ensure consistent column name for user id ---
if "user_id" not in meta_df.columns:
    if "userid" in meta_df.columns:
        meta_df.rename(columns={"userid": "user_id"}, inplace=True)
    elif "user id" in meta_df.columns:
        meta_df.rename(columns={"user id": "user_id"}, inplace=True)
    elif "user_id" not in meta_df.columns and "user_id" in [c.lower() for c in meta_df.columns]:
        meta_df.rename(columns={c: "user_id" for c in meta_df.columns if c.lower() == "user_id"}, inplace=True)
    elif "user_id" not in meta_df.columns and "user_id" in [c.lower() for c in meta_df.columns]:
        meta_df.rename(columns={c: "user_id" for c in meta_df.columns if c.lower() == "user_id"}, inplace=True)
    elif "user_id" not in meta_df.columns and "user_id" in [c.lower() for c in meta_df.columns]:
        meta_df.rename(columns={c: "user_id" for c in meta_df.columns if c.lower() == "user_id"}, inplace=True)
    elif "user_id" not in meta_df.columns:
        for c in meta_df.columns:
            if "user" in c and "id" in c:
                meta_df.rename(columns={c: "user_id"}, inplace=True)
                print(f"🔧 Renamed column '{c}' → 'user_id'")
                break

if "user_id" not in features_df.columns:
    for c in features_df.columns:
        if "user" in c and "id" in c:
            features_df.rename(columns={c: "user_id"}, inplace=True)
            print(f"🔧 Renamed column '{c}' → 'user_id'")
            break

# --- Safety check ---
if "user_id" not in features_df.columns or "user_id" not in meta_df.columns:
    raise ValueError("❌ user_id column not found in one of the dataframes. Please check column names manually.")

# --- Merge on user_id ---
merged_df = pd.merge(features_df, meta_df, on="user_id", how="left")

# --- Drop rows without COVID label ---
merged_df = merged_df.dropna(subset=["covid_test_status"])

print(f"🧩 After merging: {len(merged_df)} rows remain (with valid COVID labels)")

# --- Find which user_id were missing ---
missing_ids = set(features_df["user_id"]) - set(meta_df["user_id"])
if missing_ids:
    print(f"⚠️ {len(missing_ids)} user_id(s) not found in metadata. Example:")
    print(list(missing_ids)[:10])
else:
    print("✅ All user_id from features found in metadata!")

# --- Save merged dataset ---
merged_df.to_csv(OUTPUT_CSV, index=False)
print(f"💾 Saved merged dataset to: {OUTPUT_CSV}")

# --- Quick check ---
print("\nExample rows:")
print(merged_df.head(3))

import pandas as pd

META_CSV = "/Users/kemingliu/Desktop/CoronaHack-Respiratory-Sound-Dataset/Corona-Hack-Respiratory-Sound-Metadata.csv"
MERGED_CSV = "/Users/kemingliu/Desktop/CoronaHack-Respiratory-Sound-Dataset/output/merged_dataset.csv"
MODEL_INPUT_CSV = "/Users/kemingliu/Desktop/CoronaHack-Respiratory-Sound-Dataset/output/model_input.csv"

print("=== 🔍 Step 1: Raw Metadata ===")
meta = pd.read_csv(META_CSV, encoding_errors='ignore')
print("Available columns:", [c for c in meta.columns if 'COVID' in c])
print(meta["COVID_test_status"].value_counts(dropna=False))

print("\n=== 🔍 Step 2: After Merge (merged_dataset.csv) ===")
merged = pd.read_csv(MERGED_CSV)
if "covid_test_status" in merged.columns:
    print(merged["covid_test_status"].value_counts(dropna=False))
else:
    print("⚠️ Column 'covid_test_status' not found in merged dataset.")

print("\n=== 🔍 Step 3: Final Model Input ===")
model = pd.read_csv(MODEL_INPUT_CSV)
if "covid_test_status" in model.columns:
    print(model["covid_test_status"].value_counts(dropna=False))
else:
    print("⚠️ Column 'covid_test_status' not found in model input.")

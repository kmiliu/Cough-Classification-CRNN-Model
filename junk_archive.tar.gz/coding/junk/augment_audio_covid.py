import os
import librosa
import numpy as np
import soundfile as sf
import pandas as pd
from tqdm import tqdm

# === Paths ===
MERGED_CSV = "/Users/kemingliu/Desktop/CoronaHack-Respiratory-Sound-Dataset/output/merged_dataset.csv"
AUDIO_DIR = "/Users/kemingliu/Desktop/CoronaHack-Respiratory-Sound-Dataset/output/processed_audio"
OUTPUT_DIR = "/Users/kemingliu/Desktop/CoronaHack-Respiratory-Sound-Dataset/output/processed_audio_augmented"
LOG_CSV = os.path.join(OUTPUT_DIR, "augmentation_log.csv")

os.makedirs(OUTPUT_DIR, exist_ok=True)

# === Load metadata to find COVID-positive files ===
meta = pd.read_csv(MERGED_CSV)
positive_files = meta[meta["covid_test_status"] == 1.0]["relpath"].dropna().unique().tolist()
print(f"✅ Found {len(positive_files)} COVID-positive audio paths to augment.")

# === Helper Functions ===
def add_noise(y, noise_factor=0.005):
    noise = np.random.randn(len(y))
    augmented = y + noise_factor * noise
    return np.clip(augmented, -1.0, 1.0)

def change_speed(y, rate=1.1):
    try:
        return librosa.effects.time_stretch(y, rate=rate)
    except TypeError:
        import pyrubberband as pyrb
        return pyrb.time_stretch(y, 16000, rate)


def change_pitch(y, sr, n_steps=2):
    return librosa.effects.pitch_shift(y, sr=sr, n_steps=n_steps)

# === Process Each Positive Sample ===
augmented_data = []

for relpath in tqdm(positive_files, desc="Augmenting audio"):
    src_path = os.path.join(AUDIO_DIR, relpath)
    if not os.path.exists(src_path):
        continue

    try:
        y, sr = librosa.load(src_path, sr=16000)

        # Skip empty or very short clips
        if len(y) < sr * 0.5:
            continue

        # 1️⃣ Add Noise
        y_noise = add_noise(y)
        out1 = src_path.replace(AUDIO_DIR, OUTPUT_DIR).replace(".wav", "_noise.wav")
        os.makedirs(os.path.dirname(out1), exist_ok=True)
        sf.write(out1, y_noise, sr)
        augmented_data.append([relpath, "noise", out1])

        # 2️⃣ Change Speed (slightly faster)
        y_speed = change_speed(y, rate=1.1)
        out2 = src_path.replace(AUDIO_DIR, OUTPUT_DIR).replace(".wav", "_speed.wav")
        sf.write(out2, y_speed, sr)
        augmented_data.append([relpath, "speed", out2])

        # 3️⃣ Change Pitch (up by 2 semitones)
        y_pitch = change_pitch(y, sr, n_steps=2)
        out3 = src_path.replace(AUDIO_DIR, OUTPUT_DIR).replace(".wav", "_pitch.wav")
        sf.write(out3, y_pitch, sr)
        augmented_data.append([relpath, "pitch", out3])

    except Exception as e:
        print(f"⚠️ Error processing {src_path}: {e}")

# === Save Log ===
if augmented_data:
    df_aug = pd.DataFrame(augmented_data, columns=["original_relpath", "augmentation_type", "augmented_path"])
    df_aug.to_csv(LOG_CSV, index=False)
    print(f"\n💾 Saved augmentation log with {len(df_aug)} new samples → {LOG_CSV}")
else:
    print("\n⚠️ No augmented data generated. Check paths or conditions.")

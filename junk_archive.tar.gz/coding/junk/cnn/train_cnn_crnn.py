# coding: utf-8
"""
Train a CRNN (CNN + BiGRU) on mel-spectrograms with original train/test split.
Requires:
- output/dl_index.csv  (columns: filepath, label, split)
"""

import os, random
import numpy as np
import pandas as pd
from pathlib import Path
import librosa
import soundfile as sf
import tensorflow as tf
from tensorflow.keras import layers, models, optimizers, callbacks
from sklearn.utils.class_weight import compute_class_weight
from sklearn.metrics import classification_report, roc_auc_score

BASE = Path(__file__).resolve().parents[1]
OUT  = BASE / "output"
INDEX_CSV = OUT / "dl_index.csv"
assert INDEX_CSV.exists(), f"Missing: {INDEX_CSV}"

# --------- Config ---------
SR = 16000             # sample rate
DUR = 5.0              # seconds kept (crop/pad)
N_SAMPLES = int(SR * DUR)

N_MELS = 128
N_FFT = 400            # 25 ms @ 16k
HOP = 160              # 10 ms @ 16k

BATCH_SIZE = 16
EPOCHS = 30
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
tf.random.set_seed(SEED)

# --------- Utils ---------
def load_audio(path, sr=SR):
    """Load mono audio, return float32 array."""
    y, s = librosa.load(path, sr=sr, mono=True)
    return y.astype(np.float32)

def fix_length_train(y):
    """Random crop or pad to N_SAMPLES for training."""
    if len(y) > N_SAMPLES:
        start = np.random.randint(0, len(y) - N_SAMPLES + 1)
        y = y[start: start + N_SAMPLES]
    elif len(y) < N_SAMPLES:
        pad = N_SAMPLES - len(y)
        y = np.pad(y, (0, pad), mode="constant")
    return y

def fix_length_eval(y):
    """Center crop or pad to N_SAMPLES for evaluation."""
    if len(y) > N_SAMPLES:
        start = (len(y) - N_SAMPLES) // 2
        y = y[start: start + N_SAMPLES]
    elif len(y) < N_SAMPLES:
        pad = N_SAMPLES - len(y)
        y = np.pad(y, (0, pad), mode="constant")
    return y

def to_melspec(y, sr=SR):
    """Compute log-mel spectrogram (time x mel)"""
    S = librosa.feature.melspectrogram(
        y=y, sr=sr, n_fft=N_FFT, hop_length=HOP, n_mels=N_MELS, power=2.0
    )
    logS = librosa.power_to_db(S, ref=np.max)
    # normalize per sample
    logS = (logS - logS.mean()) / (logS.std() + 1e-8)
    # return shape (time, mel, 1)
    return np.expand_dims(logS.T, axis=-1)

def data_generator(df, batch_size, training=True):
    """Yield batches of (mel, label)."""
    idx = np.arange(len(df))
    while True:
        if training:
            np.random.shuffle(idx)
        for i in range(0, len(df), batch_size):
            batch_idx = idx[i:i+batch_size]
            xs, ys = [], []
            for j in batch_idx:
                path = df.iloc[j]["filepath"]
                label = int(df.iloc[j]["label"])
                if not Path(path).exists():
                    continue
                y = load_audio(path)
                y = fix_length_train(y) if training else fix_length_eval(y)
                mel = to_melspec(y)
                xs.append(mel)
                ys.append(label)
            if xs:
                X = np.stack(xs, axis=0)   # (B, T, M, 1)
                Y = np.array(ys).astype(np.float32)
                yield X, Y

# --------- Model (CRNN) ---------
def build_crnn(input_shape=(None, N_MELS, 1)):
    """CRNN: Conv blocks -> reshape -> BiGRU -> Dense"""
    inp = layers.Input(shape=input_shape)
    x = inp

    # 2D Conv blocks
    for f in [32, 64, 96]:
        x = layers.Conv2D(f, (3,3), padding="same")(x)
        x = layers.BatchNormalization()(x)
        x = layers.ReLU()(x)
        x = layers.MaxPooling2D((2,2))(x)
        x = layers.Dropout(0.2)(x)

    # Now shape is (T', M', C). Merge mel & channels, keep time as first axis
    # We want (batch, time, features)
    t, m, c = x.shape[1], x.shape[2], x.shape[3]
    x = layers.Reshape((-1, int(m*c)))(x)

    # BiGRU
    x = layers.Bidirectional(layers.GRU(128, return_sequences=True))(x)
    x = layers.Bidirectional(layers.GRU(64))(x)
    x = layers.Dropout(0.3)(x)

    out = layers.Dense(1, activation="sigmoid")(x)
    model = models.Model(inputs=inp, outputs=out)
    model.compile(
        optimizer=optimizers.Adam(1e-3),
        loss="binary_crossentropy",
        metrics=["AUC", "Precision", "Recall"]
    )
    return model

# --------- Load index and split ---------
index_df = pd.read_csv(INDEX_CSV)
index_df = index_df[index_df["label"].isin([0,1])].copy()

train_df = index_df[index_df["split"] == "train"].reset_index(drop=True)
test_df  = index_df[index_df["split"] == "test"].reset_index(drop=True)

print(f"✅ Train files: {len(train_df)}")
print(f"✅ Test files : {len(test_df)}")
print("Train label counts:\n", train_df["label"].value_counts())
print("Test  label counts:\n", test_df["label"].value_counts())

# --------- Class weight ---------
classes = np.array([0,1])
class_w = compute_class_weight("balanced", classes=classes, y=train_df["label"].values)
class_weight = {0: float(class_w[0]), 1: float(class_w[1])}
print("🔧 Class weights:", class_weight)

# --------- Dataset generators ---------
steps_per_epoch = max(1, len(train_df)//BATCH_SIZE)
val_split = 0.1
val_n = int(len(train_df)*val_split)
train_core = train_df.iloc[:-val_n] if val_n>0 else train_df
val_core   = train_df.iloc[-val_n:] if val_n>0 else train_df.iloc[0:0]

train_gen = data_generator(train_core, BATCH_SIZE, training=True)
val_gen   = data_generator(val_core, BATCH_SIZE, training=False) if val_n>0 else None
test_gen  = data_generator(test_df, BATCH_SIZE, training=False)

# --------- Build & Train ---------
model = build_crnn()
model.summary()

ckpt = callbacks.ModelCheckpoint(
    filepath=str(OUT / "crnn_best.h5"),
    monitor="val_auc" if val_n>0 else "auc",
    mode="max",
    save_best_only=True,
    save_weights_only=False,
    verbose=1
)
early = callbacks.EarlyStopping(
    monitor="val_auc" if val_n>0 else "auc",
    patience=5,
    mode="max",
    restore_best_weights=True,
    verbose=1
)

history = model.fit(
    train_gen,
    steps_per_epoch=max(1, len(train_core)//BATCH_SIZE),
    epochs=EPOCHS,
    validation_data=val_gen if val_n>0 else None,
    validation_steps=max(1, len(val_core)//BATCH_SIZE) if val_n>0 else None,
    class_weight=class_weight,
    callbacks=[ckpt, early],
    verbose=1
)

# --------- Evaluate on test ---------
# Collect all test predictions
y_true, y_proba = [], []
for Xb, Yb in test_gen:
    y_true.extend(Yb.tolist())
    pb = model.predict(Xb, verbose=0).ravel().tolist()
    y_proba.extend(pb)
    if len(y_true) >= len(test_df):
        break

y_true = np.array(y_true[:len(test_df)])
y_proba = np.array(y_proba[:len(test_df)])
auc = roc_auc_score(y_true, y_proba) if len(np.unique(y_true))==2 else np.nan
print(f"\n🌟 Test AUC: {auc:.4f}")

# Threshold tuning to maximize F1
from sklearn.metrics import precision_recall_curve, classification_report
prec, rec, thr = precision_recall_curve(y_true, y_proba)
f1 = (2*prec*rec) / (prec+rec+1e-9)
best_idx = np.nanargmax(f1)
best_thr = thr[best_idx] if best_idx < len(thr) else 0.5
y_pred = (y_proba >= best_thr).astype(int)
print(f"🎯 Best threshold = {best_thr:.3f}")
print("\n📊 Test Classification Report (tuned threshold):")
print(classification_report(y_true, y_pred, digits=4))

# Save metrics
pd.DataFrame({
    "test_auc":[auc],
    "best_thr":[best_thr]
}).to_csv(OUT / "crnn_eval_summary.csv", index=False)
print(f"\n💾 Saved summary to: {OUT/'crnn_eval_summary.csv'}")

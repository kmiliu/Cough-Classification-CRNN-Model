# coding: utf-8
"""
Build a deep-learning index CSV listing (filepath, label, split) for CNN/CRNN training.
- Reads merged_dataset.csv (has relpath + covid_test_status + split)
- Maps to processed audio under output/processed_audio
- Also appends augmented positives under output/processed_audio_augmented (label=1, split=train)
"""

import os
import pandas as pd
from pathlib import Path
from glob import glob

BASE = Path(__file__).resolve().parents[1]
OUT = BASE / "output"
MERGED = OUT / "merged_dataset.csv"
PROC_DIR = OUT / "processed_audio"
AUG_DIR  = OUT / "processed_audio_augmented"
INDEX_CSV = OUT / "dl_index.csv"

assert MERGED.exists(), f"Missing: {MERGED}"
assert PROC_DIR.exists(), f"Missing processed dir: {PROC_DIR}"

df = pd.read_csv(MERGED)
# Keep required columns
need_cols = ["relpath", "covid_test_status", "split"]
for c in need_cols:
    if c not in df.columns:
        raise ValueError(f"Missing column '{c}' in {MERGED}")

# Map relpath -> absolute processed path
def to_proc_path(rel):
    return str(PROC_DIR / rel)

df["filepath"] = df["relpath"].apply(to_proc_path)
df["label"] = pd.to_numeric(df["covid_test_status"], errors="coerce").astype("Int64")
df = df[df["label"].isin([0, 1])]  # keep only labeled

# Keep only files that actually exist
df = df[df["filepath"].apply(lambda p: Path(p).exists())].copy()

base_rows = df[["filepath", "label", "split"]].copy()

# Append augmented positives if available
aug_rows = []
if AUG_DIR.exists():
    aug_files = glob(str(AUG_DIR / "**/*.wav"), recursive=True)
    for f in aug_files:
        aug_rows.append({"filepath": f, "label": 1, "split": "train"})
    if aug_rows:
        aug_df = pd.DataFrame(aug_rows)
        base_rows = pd.concat([base_rows, aug_df], ignore_index=True)
        print(f"✅ Added augmented positives: {len(aug_df)} files")

# Drop duplicates and save
base_rows = base_rows.drop_duplicates().reset_index(drop=True)
base_rows.to_csv(INDEX_CSV, index=False)
print(f"✅ Saved deep-learning index to: {INDEX_CSV}")
print(base_rows["split"].value_counts())
print(base_rows["label"].value_counts())

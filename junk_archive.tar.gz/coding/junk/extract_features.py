import os
import librosa
import numpy as np
import pandas as pd
from tqdm import tqdm

# === Paths ===
DATA_DIR = "/Users/kemingliu/Desktop/CoronaHack-Respiratory-Sound-Dataset/output/filtered_audio"
OUTPUT_CSV = "/Users/kemingliu/Desktop/CoronaHack-Respiratory-Sound-Dataset/output/features2.csv"

def parse_path_fields(abs_path, root):
    """
    Parse fields from absolute path relative to root:
    Expect structure like: filtered_audio/<split>/<date>/<user_id>/<filename>
    Returns (relpath, split, date, user_id, file_type, filename)
    """
    relpath = os.path.relpath(abs_path, root)
    parts = relpath.split(os.sep)

    # Default values if structure is unexpected
    split = parts[0] if len(parts) >= 1 else ""
    date = parts[1] if len(parts) >= 2 else ""
    user_id = parts[2] if len(parts) >= 3 else ""
    filename = parts[-1]
    file_type = os.path.splitext(filename)[0]  # e.g., counting-normal.wav -> counting-normal
    return relpath, split, date, user_id, file_type, filename

def extract_audio_features(file_path):
    """
    Extract MFCC (13), Chroma (12), Spectral Centroid, Bandwidth, Rolloff, ZCR.
    Returns a 1D numpy array of features or None on failure/too-short clips.
    """
    try:
        y, sr = librosa.load(file_path, sr=16000)
        if y is None or len(y) < 2048:
            return None

        mfccs = np.mean(librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13).T, axis=0)
        chroma = np.mean(librosa.feature.chroma_stft(y=y, sr=sr).T, axis=0)
        spec_centroid = float(np.mean(librosa.feature.spectral_centroid(y=y, sr=sr)))
        spec_bw = float(np.mean(librosa.feature.spectral_bandwidth(y=y, sr=sr)))
        rolloff = float(np.mean(librosa.feature.spectral_rolloff(y=y, sr=sr)))
        zcr = float(np.mean(librosa.feature.zero_crossing_rate(y)))

        return np.hstack([mfccs, chroma, [spec_centroid, spec_bw, rolloff, zcr]])
    except Exception as e:
        print(f"❌ Error processing {file_path}: {e}")
        return None

def main():
    wavs = []
    for root, _, files in os.walk(DATA_DIR):
        for f in files:
            if f.lower().endswith(".wav"):
                wavs.append(os.path.join(root, f))

    print(f"🔍 Found {len(wavs)} wav files under {DATA_DIR}")

    rows = []
    for fp in tqdm(wavs, desc="Extracting features"):
        feats = extract_audio_features(fp)
        if feats is None:
            continue

        relpath, split, date, user_id, file_type, filename = parse_path_fields(fp, DATA_DIR)

        row = {
            "relpath": relpath,
            "split": split,
            "date": date,
            "user_id": user_id,
            "file_type": file_type,
            "filename": filename,
        }
        # append features with stable names
        for i in range(13):
            row[f"mfcc_{i+1}"] = float(feats[i])
        for i in range(12):
            row[f"chroma_{i+1}"] = float(feats[13 + i])
        row["spec_centroid"] = float(feats[-4])
        row["spec_bw"] = float(feats[-3])
        row["rolloff"] = float(feats[-2])
        row["zcr"] = float(feats[-1])

        rows.append(row)

    if not rows:
        print("⚠️ No features extracted. Check your input folder.")
        return

    df = pd.DataFrame(rows)
    df.to_csv(OUTPUT_CSV, index=False)
    print(f"💾 Saved features with IDs to: {OUTPUT_CSV}")
    print(f"✅ Rows: {len(df)}  |  Columns: {len(df.columns)}")

if __name__ == "__main__":
    main()

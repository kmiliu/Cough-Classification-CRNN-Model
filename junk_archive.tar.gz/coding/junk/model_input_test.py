import pandas as pd
import os
import numpy as np

# === Paths ===
MERGED_CSV = "/Users/kemingliu/Desktop/CoronaHack-Respiratory-Sound-Dataset/output/merged_dataset.csv"
MODEL_INPUT_TEST_CSV = "/Users/kemingliu/Desktop/CoronaHack-Respiratory-Sound-Dataset/output/model_input_test.csv"

# === Load merged dataset ===
df = pd.read_csv(MERGED_CSV)
print(f"✅ Loaded merged dataset with {len(df)} rows and {len(df.columns)} columns")

# === Filter only testing data ===
if "split" not in df.columns:
    raise ValueError("❌ 'split' column not found in merged_dataset.csv — cannot separate train/test.")
df = df[df["split"] == "test"].copy()
print(f"📦 Using only testing samples: {len(df)} rows")

# === Select acoustic features + numeric label ===
feature_cols = [c for c in df.columns if c.startswith(("mfcc_", "chroma_", "spec_", "zcr"))]
label_col = "covid_test_status"

if label_col not in df.columns:
    raise ValueError("❌ Column 'covid_test_status' not found. Check merged CSV.")

model_df = df[feature_cols + [label_col]].copy()

# --- Handle numeric labels ---
model_df[label_col] = pd.to_numeric(model_df[label_col], errors='coerce')
model_df = model_df[model_df[label_col].isin([0, 1])]
model_df[label_col] = model_df[label_col].astype(int)
model_df = model_df.dropna(subset=[label_col])

# --- Save cleaned model input ---
os.makedirs(os.path.dirname(MODEL_INPUT_TEST_CSV), exist_ok=True)
model_df.to_csv(MODEL_INPUT_TEST_CSV, index=False)

# --- Summary ---
print(f"💾 Saved model_input_test.csv with {len(model_df)} samples and {len(feature_cols)} features")
print("Label distribution:")
print(model_df[label_col].value_counts())

import os, shutil

base = "/Users/kemingliu/Desktop/CoronaHack-Respiratory-Sound-Dataset/output"
src_train = os.path.join(base, "processed_audio/train")
src_aug = os.path.join(base, "processed_audio_augmented/train")
dst = os.path.join(base, "processed_audio_clean/train")

os.makedirs(dst, exist_ok=True)

for root in [src_train, src_aug]:
    for path, _, files in os.walk(root):
        for f in files:
            if f.endswith(".wav"):
                src = os.path.join(path, f)
                rel = os.path.relpath(src, root)
                dst_path = os.path.join(dst, rel)
                os.makedirs(os.path.dirname(dst_path), exist_ok=True)
                shutil.copy2(src, dst_path)

print("✅ combination complete: original train + augmented")
